package com.example.vocav;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class WordAdapter  extends RecyclerView.Adapter<WordAdapter.WordViewHolder>{

    Context ctx;
    List<Word> data;

    public WordAdapter(Context ctx, List<Word> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View root = LayoutInflater.from(ctx).inflate(R.layout.row_word,parent,false);
        WordViewHolder holder = new WordViewHolder(root);

        holder.setIsRecyclable(false);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {

        // CHANGE THIS

        //it needs to write words english name initially in screen
        holder.txtName.setText(data.get(position).getEnglishWord());

        ExecutorService srv = ((WordApplication)((Activity)ctx).getApplication()).srv;


        holder.downloadImage(srv,data.get(position).getImagePath());

        holder.row.setOnClickListener(v->{

            NavController navController =
                    Navigation.findNavController((Activity) ctx,R.id.fragmentContainer);

            Bundle dataBundle = new Bundle();

            dataBundle.putString("id",data.get(holder.getAdapterPosition()).getId());

            navController.navigate(R.id.action_fragmentListWord_to_fragmentDetails,dataBundle);


        });


    }

    //dont change
    @Override
    public int getItemCount() {
        return data.size();
    }

    static class WordViewHolder extends RecyclerView.ViewHolder{

        ConstraintLayout row;
        TextView txtName;
        ImageView imgWord;

        boolean imageDownloaded;


        Handler imageHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {

                imgWord.setImageBitmap((Bitmap) msg.obj);
                imageDownloaded = true;

                return true;
            }
        });


        public WordViewHolder(@NonNull View itemView) {
            super(itemView);
            row = itemView.findViewById(R.id.row_list);
            txtName = itemView.findViewById(R.id.txtListName);
            imgWord = itemView.findViewById(R.id.imgList);
        }

        public void downloadImage(ExecutorService srv, String path){

            if(!imageDownloaded){
                WordRepo repo = new WordRepo();
                repo.downloadImage(srv,imageHandler,path);
            }


        }
    }


}