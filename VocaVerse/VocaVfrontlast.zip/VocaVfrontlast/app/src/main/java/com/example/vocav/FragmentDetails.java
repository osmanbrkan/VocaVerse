package com.example.vocav;

import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vocav.databinding.FragmentDetailsBinding;

import java.util.concurrent.ExecutorService;

public class FragmentDetails extends Fragment {

    FragmentDetailsBinding binding;

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            Word word = (Word)msg.obj;
            binding.txtNameDetail.setText(word.getEnglishWord());
            binding.textTr.setText(word.getTurkishWord());
            binding.textSpn.setText(word.getSpanishWord());
            binding.textFrn.setText(word.getFrenchWord());


            ((MainActivity)getActivity()).getToolBar().setTitle(word.getEnglishWord());


            WordRepo repo = new WordRepo();
            ExecutorService srv = ((WordApplication)getActivity().getApplication()).srv;
            repo.downloadImage(srv,imgHandler,word.getImagePath());



            return true;

        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            binding.imgDetails.setImageBitmap((Bitmap)msg.obj);


            return true;
        }
    });


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDetailsBinding.inflate(getLayoutInflater());

        //int operid =  getArguments().getInt("operid");
        String id = getArguments().getString("id");  //we store id as string

        WordRepo repo = new WordRepo();
        ExecutorService srv = ((WordApplication)getActivity().getApplication()).srv;

        repo.getDataById(srv,handler,id);

        return binding.getRoot();
    }
}