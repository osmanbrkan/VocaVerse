package com.example.vocav;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.vocav.databinding.FragmentListWordBinding;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class FragmentListWord extends Fragment {


    FragmentListWordBinding binding;


    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            List<Word> data = (List<Word>) msg.obj;

            WordAdapter adp = new WordAdapter(getActivity(),data);
            binding.recView.setAdapter(adp);

            return true;
        }
    });


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentListWordBinding.inflate(getLayoutInflater());
        ((MainActivity)getActivity()).getToolBar().setTitle("VocaVerse");
        binding.recView.setLayoutManager(new LinearLayoutManager(getActivity()));


        WordRepo repo = new WordRepo();

        ExecutorService srv=((WordApplication)getActivity().getApplication()).srv;

        //Get all word
        repo.getAllWords(srv,dataHandler);


        return binding.getRoot();
    }
}