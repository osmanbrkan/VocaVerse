package com.example.vocav;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
public class WordRepo {



    public void getAllWords(ExecutorService srv, Handler uiHandler){


        srv.submit(()->{
            try {

                List<Word> data = new ArrayList<>();

                URL url =
                        new URL("http://10.0.2.2:8080/vocaverse/words");


                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader
                        = new BufferedReader(
                        new InputStreamReader(
                                conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line;
                while((line=reader.readLine())!=null){
                    buffer.append(line);
                }

                JSONArray arr = new JSONArray(buffer.toString());

                for (int i = 0; i <arr.length() ; i++) {

                    JSONObject current = arr.getJSONObject(i);

                    Word word = new Word(current.getString("id"),
                            current.getString("level"),
                            current.getString("imagePath"),
                            current.getString("englishWord"),
                            current.getString("turkishWord"),
                            current.getString("spanishWord"),
                            current.getString("frenchWord")
                    );

                    data.add(word);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);



            } catch (MalformedURLException e) {
                Log.e("DEV1",e.getMessage());
            } catch (IOException e) {
                Log.e("DEV2",e.getMessage());
            } catch (JSONException e) {
                Log.e("DEV3",e.getMessage());
            }


        });

    }

    //get data by id
    public void getDataById(ExecutorService srv, Handler uiHandler,String id) {


        srv.execute(() -> {
            try {
                URL url = new URL("http://10.0.2.2:8080/vocaverse/words/id/" + id);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();


                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {

                    buffer.append(line);

                }

                JSONObject current = new JSONObject(buffer.toString());

                Word word = new Word(current.getString("id"),
                        current.getString("level"),
                        current.getString("imagePath"),
                        current.getString("englishWord"),
                        current.getString("turkishWord"),
                        current.getString("spanishWord"),
                        current.getString("frenchWord")
                );

                Message msg = new Message();
                msg.obj = word;
                uiHandler.sendMessage(msg);


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        });

    }

    //download image
    public void downloadImage(ExecutorService srv, Handler uiHandler, String path){

        srv.submit(()->{
            try {
                URL url =
                        new URL(path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                Bitmap bmp = BitmapFactory.decodeStream(conn.getInputStream());

                Message msg = new Message();
                msg.obj = bmp;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


        });





    }













}
