package com.sabanciuniv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VocaVApplication {

	public static void main(String[] args) {
		SpringApplication.run(VocaVApplication.class, args);
	}

}
